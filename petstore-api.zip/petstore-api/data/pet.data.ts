import { faker } from "@faker-js/faker";

export class PetData {
  static generatePet() {
    return {
      id: faker.number.int({ min: 1000, max: 9999 }),
      name: faker.animal.type(),
      status: "available",
      category: {
        id: faker.number.int({ min: 1, max: 1000 }),
        name: faker.animal.type(),
      },
      photoUrls: ["https://example.com/photo.jpg"],
      tags: [{ id: faker.number.int({ min: 1, max: 1000 }), name: "tag1" }],
    };
  }
}
