import { PetStoreMock } from "../mocks/pet.mock";

export class PetApi {
  async createPet(pet: any) {
    if (!pet || !pet.id || !pet.name) {
      console.log("CREATE STATUS: 400 Bad Request");
      return {
        status: 400,
        body: { message: "Bad Request: missing id or name" },
      };
    }
    const created = PetStoreMock.createPet(pet);
    console.log("CREATE STATUS: 201", created);
    return { status: 201, body: created };
  }

  async getPet(id: number) {
    if (!id) {
      console.log("GET STATUS: 400 Bad Request");
      return { status: 400, body: { message: "Bad Request: missing id" } };
    }

    const pet = PetStoreMock.getPet(id);
    const status = pet ? 200 : 404;

    console.log(`GET STATUS: ${status}`, pet ?? { message: "Pet not found" });

    return {
      status,
      body: pet ?? { message: "Pet not found" },
    };
  }

  async updatePet(pet: any) {
    if (!pet || !pet.id) {
      console.log("UPDATE STATUS: 400 Bad Request");
      return { status: 400, body: { message: "Bad Request: missing id" } };
    }
    const updated = PetStoreMock.updatePet(pet);
    const status = updated ? 200 : 404;
    console.log(`UPDATE STATUS: ${status}`, updated);
    return { status, body: updated };
  }

  async deletePet(id: number) {
    if (!id) {
      console.log("DELETE STATUS: 400 Bad Request");
      return { status: 400, body: { message: "Bad Request: missing id" } };
    }
    const result = PetStoreMock.deletePet(id);
    const status = result.message === "No Content" ? 204 : 404;
    console.log(`DELETE STATUS: ${status}`, result);
    return { status, body: result };
  }
  async simulateServerError() {
    console.log("SERVER ERROR STATUS: 500");
    return {
      status: 500,
      body: { message: "Internal Server Error" },
    };
  }
}
