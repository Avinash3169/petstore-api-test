interface Pet {
  id: number;
  name: string;
  status: string;
  category: { id: number; name: string };
  photoUrls: string[];
  tags: { id: number; name: string }[];
}

export const PetStoreMock = {
  pets: new Map<number, Pet>(),

  createPet(pet: Pet) {
    this.pets.set(pet.id, pet);
    return pet;
  },

  getPet(id: number) {
    return this.pets.get(id) || null;
  },

  updatePet(pet: Pet) {
    if (!this.pets.has(pet.id)) return null;
    this.pets.set(pet.id, pet);
    return pet;
  },

  deletePet(id: number) {
    if (!this.pets.has(id)) return { message: "Not Found" };
    this.pets.delete(id);
    return { message: "No Content" };
  },
};
