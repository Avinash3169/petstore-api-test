import { test, expect } from "@playwright/test";
import { PetApi } from "../apis/pet.api";
import { PetData } from "../data/pet.data";
import { PetStoreMock } from "../mocks/pet.mock";

test.describe("PetStore API CRUD)", () => {
  test("Full CRUD flow", async () => {
    const petApi = new PetApi();
    const testPet = PetData.generatePet();

    const log = (title: string, obj: any, status?: number) => {
      console.log(`\n=== ${title} ===`);
      if (status) console.log("Status:", status);
      console.log(JSON.stringify(obj, null, 2));
    };

    // Helper to safely read message or id
    const safeMessage = (res: any, fallback: string) =>
      res?.body?.message || fallback;
    const safeId = (res: any) => res?.body?.id || "unknown";
    const safeStatus = (res: any) => res?.body?.status || "unknown";

    const summary: { step: string; status: number; message: string }[] = [];

    // ----- CREATE -----
    const created = await petApi.createPet(testPet);
    log("CREATED PET", created.body, created.status);
    expect(created.status).toBe(201);
    summary.push({
      step: "CREATE",
      status: created.status,
      message: `Created pet ${safeId(created)}`,
    });

    // ----- CREATE 400 -----
    const invalidCreate = await petApi.createPet({});
    log("CREATE INVALID (400)", invalidCreate.body, invalidCreate.status);
    expect(invalidCreate.status).toBe(400);
    summary.push({
      step: "CREATE 400",
      status: invalidCreate.status,
      message: safeMessage(invalidCreate, "Bad Request: missing id or name"),
    });

    // ----- GET -----
    const fetched = await petApi.getPet(created.body?.id);
    log("FETCHED PET", fetched.body, fetched.status);
    expect(fetched.status).toBe(200);
    summary.push({ step: "GET", status: fetched.status, message: "Pet found" });

    // ----- GET 400 -----
    const fetched400 = await petApi.getPet(undefined as any);
    log("GET INVALID (400)", fetched400.body, fetched400.status);
    expect(fetched400.status).toBe(400);
    summary.push({
      step: "GET 400",
      status: fetched400.status,
      message: safeMessage(fetched400, "Bad Request: missing id"),
    });

    // ----- GET 404 -----
    const fetched404 = await petApi.getPet(999999);
    log("GET NOT FOUND (404)", fetched404.body, fetched404.status);
    expect(fetched404.status).toBe(404);
    summary.push({
      step: "GET 404",
      status: fetched404.status,
      message: "Pet not found",
    });

    // ----- SIMULATE 500 ERROR -----
    const simulate500 = await petApi.simulateServerError();
    log("SIMULATE 500", simulate500.body, simulate500.status);
    expect(simulate500.status).toBe(500);
    summary.push({
      step: "SIMULATE 500",
      status: simulate500.status,
      message: safeMessage(simulate500, "Internal Server Error"),
    });

    // ----- UPDATE -----
    testPet.status = "sold";
    const updated = await petApi.updatePet(testPet);
    log("UPDATED PET", updated.body, updated.status);
    expect(updated.status).toBe(200);
    summary.push({
      step: "UPDATE",
      status: updated.status,
      message: `Updated status to ${safeStatus(updated)}`,
    });

    // ----- UPDATE 404 -----
    const update404 = await petApi.updatePet({ id: 888888, name: "ghost" });
    log("UPDATE NOT FOUND (404)", update404.body, update404.status);
    expect(update404.status).toBe(404);
    summary.push({
      step: "UPDATE 404",
      status: update404.status,
      message: "Pet not found",
    });

    // ----- DELETE -----
    const deleted = await petApi.deletePet(testPet.id);
    log("DELETED PET", deleted.body, deleted.status);
    expect(deleted.status).toBe(204);
    summary.push({
      step: "DELETE",
      status: deleted.status,
      message: safeMessage(deleted, "No Content"),
    });

    // ----- DELETE 404 -----
    const delete404 = await petApi.deletePet(777777);
    log("DELETE NOT FOUND (404)", delete404.body, delete404.status);
    expect(delete404.status).toBe(404);
    summary.push({
      step: "DELETE 404",
      status: delete404.status,
      message: "Pet not found",
    });

    // ----- GET AFTER DELETE -----
    const fetchedAfterDelete = await petApi.getPet(testPet.id);
    log(
      "FETCHED AFTER DELETE",
      fetchedAfterDelete.body,
      fetchedAfterDelete.status
    );
    expect(fetchedAfterDelete.status).toBe(404);
    summary.push({
      step: "GET AFTER DELETE",
      status: fetchedAfterDelete.status,
      message: "Pet not found",
    });

    // ----- SUMMARY TABLE -----
    console.log("\n=== CRUD SUMMARY ===");
    console.table(summary);
  });
});
